package latihan2;

import java.util.Vector;

public class infoNasabah {
	
	private String Nama;
	private int Saldo;
	private int withdraw;
	private int transfer;
	public int customerId;
	public int deposit;
	
	Maindata m = new Maindata();
	
	
	
	public void setNama(String name) {
		Nama = name;
	}
	
	public void id(int id) {
		customerId = id;
	}
	
	public void SetSaldo(int saldo) {
		Saldo = saldo;
		m.customerInfo.add(Saldo);
	}
	
	public void withdraw(int narik) {
		withdraw = narik;
		Saldo = Saldo - withdraw;
	}
	
	public void transferDuit(int Transfer) {
		transfer = Transfer;
		Saldo = Saldo - Transfer;
	}
	
	public void depositUang(int deposito) {
		deposit = deposito;
		Saldo += deposit;		
	}
	
	public String getNama(){
		return Nama;
	}
	
	public int getSaldo() {
		return Saldo;
	}
	
	
}
	

