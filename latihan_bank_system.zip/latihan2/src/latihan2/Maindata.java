package latihan2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;



public class Maindata {
	
	infoNasabah infoN = new infoNasabah();
	Scanner scan = new Scanner(System.in);
	UUID u = UUID.randomUUID();
	Random rand = new Random();
	
	Vector<Integer> customerInfo = new Vector<>(); 
	ArrayList<String> customerName = new ArrayList<>(); 
	ArrayList<Integer> customerId = new ArrayList<>();
	
	int customerNameTotal = 0;
	
	public Maindata() {
		int choice = 0;
		
	
	
		while(choice != 6){
		System.out.println("selamat datang di bank xxx, silahkan pilih menu anda: ");
		System.out.println("1. info saldo");
		System.out.println("2. withdraw: ");
		System.out.println("3. transfer");
		System.out.println("4. deposit");
		System.out.println("5. add new user: ");
		System.out.println("menu yang dipilih: ");
		try {
			choice = scan.nextInt();
			scan.nextLine();
		}catch(Exception e) {
			System.out.println("salah input, harap di coba lagi!");
		}	
		switch(choice) {
		case 1:
			showInfo();
			System.out.println("press enter to continue: ...");
			scan.nextLine();
			break;
		case 2:
			showInfo();
			System.out.println("masukan nomor index akun yang dipilih: ");
			customerInfo.add(scan.nextInt() );
			System.out.println("masukan jumlah uang yang ingin anda tarik: ");
			int withdraw = scan.nextInt();
			infoN.withdraw(withdraw);
			
			System.out.println("anda menarik uang sejumlah: " + withdraw);
			System.out.println("sisa uang anda sekarang adalah: " + infoN.getSaldo());
			System.out.println("press enter to continue: ...");
			scan.nextLine();
			break;
		case 3:
			System.out.println("masukan jumlah uang yang ingin anda transfer: ");
			int transfer = scan.nextInt();
			infoN.transferDuit(transfer);
			if(transfer > infoN.getSaldo()) {
				System.out.println("Transaksi gagal, uang anda tidak cukup! mohon masukan uang lagi: ");
				transfer = scan.nextInt();
				infoN.transferDuit(transfer);
				
			}
			else {
				System.out.println("Transaksi Berhasil");
				System.out.println("jumlah uang anda sekarang" + infoN.getSaldo());
			}
			System.out.println("press enter to continue: ...");
			scan.nextLine();
			break;
		case 4:
			System.out.println("masukan uang anda: ");
			int deposito = scan.nextInt();
			infoN.depositUang(deposito);
			System.out.println("jumlah saldo anda sekarang: " + infoN.getSaldo());
			System.out.println("apakah anda ingin melakuan transaksi lagi?");
			System.out.println("1. ya");
			System.out.println("2. tidak");
			int a = scan.nextInt();
			if(a == 1) {
				System.out.println("nasi");
			}
			else if(a == 2) {
				System.out.println("ayam");
			}
			while(a > 2) {
				System.out.println("maaf, input anda salah , moohn coba lagi: ");
				a = scan.nextInt();
			}
			System.out.println("press enter to continue: ...");
			scan.nextLine();
			break;
		case 5:
			
			System.out.println("masukan nama user: ");
			customerName.add(scan.nextLine());
			System.out.println("masukan jumlah saldo: ");
			customerInfo.add(scan.nextInt());
			customerId.add(rand.nextInt(1000));
			customerNameTotal++;
			System.out.println("press enter to continue: ");
			scan.nextLine();
			break;
			}
		clearScreen();
		}
	}
	
	private void clearScreen() {
		//Untuk merapihkan menu
		for (int i = 0; i < 30; i++) {
			System.out.println();
		}
	}
	
	public void showInfo() {
		if(customerNameTotal != 0){
			for(int k = 0; k < customerNameTotal; k++) {
			System.out.println((k+1) + "Nama Customer: " + customerName.get(k));
			System.out.println("Info Saldo: " + customerInfo.get(k));
			
			System.out.println("CustomerId: " + infoN.customerId);
			customerInfo.add(infoN.customerId);
			}
		}
		else {
			System.out.println("tidak ada data");
		}
	}
	
	public static void main(String[] args) {
		new Maindata();
	}
}
