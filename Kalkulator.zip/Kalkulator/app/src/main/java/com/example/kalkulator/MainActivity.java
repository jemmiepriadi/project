package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private TextView Screen;
private Button Delete,Answer,Mul,Button7,Button8,Button9,Divide,Button4,Button5,Button6,Plus,Button1,Button2,Button3,Substract,Koma,Button0,Ac,Equal;
private String input, answer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Screen=findViewById(R.id.screen);
        Delete=findViewById(R.id.delete);
        Mul=findViewById(R.id.mul);
        Plus=findViewById(R.id.plus);
        Divide=findViewById(R.id.divide);
        Plus=findViewById(R.id.plus);
        Substract=findViewById(R.id.substract);
        Koma=findViewById(R.id.koma);
        Ac=findViewById(R.id.AC);
        Equal=findViewById(R.id.equal);
        Button0=findViewById(R.id.button0);
        Button1=findViewById(R.id.button1);
        Button2=findViewById(R.id.button2);
        Button3=findViewById(R.id.button3);
        Button4=findViewById(R.id.button4);
        Button5=findViewById(R.id.button5);
        Button6=findViewById(R.id.button6);
        Button7=findViewById(R.id.button7);
        Button8=findViewById(R.id.button8);
        Button9=findViewById(R.id.button9);
    }
    public void ButtonClick(View view){
        Button button=(Button) view;
        String data=button.getText().toString();
        switch(data){
            case"AC":
                input="";
                break;
            case "X":
                Solve();
                input+="*";
                break;
            case "=":
                Solve();
                answer=input;
                break;
            case "DEL":
                String newText=input.substring(0,input.length()-1);
                input=newText;
                break;
            default:
                if(input==null){
                    input="";
                }
                if(data.equals("+")||data.equals("-")||data.equals("/")){
                    Solve();
                }
                input+=data;
        }
        Screen.setText(input);

    }
    private void Solve(){
        if(input.split("\\*").length==2){
            String number[]=input.split("\\*");
            try {
                double mul = Double.parseDouble(number[0]) * Double.parseDouble(number[1]);
                input = mul+"";
            }
            catch(Exception e){

            }
        }
        else if(input.split("/").length==2){
            String number[]=input.split("/");
            try {
                double div = Double.parseDouble(number[0]) / Double.parseDouble(number[1]);
                input = div+"";
            }
            catch(Exception e){

            }
        }
        else if(input.split("\\+").length==2){
            String number[]=input.split("\\+");
            try {
                double sum = Double.parseDouble(number[0]) + Double.parseDouble(number[1]);
                input = sum+"";
            }
            catch(Exception e){

            }
        }
        if(input.split("-").length>1){
            String number[]=input.split("-");
            if(number[0]==""&&number.length==2){
                number[0]=0+"";
            }
            try {
                double substract=0;
                if(number.length==2) {
                    substract = Double.parseDouble(number[0]) - Double.parseDouble(number[1]);
                }
                else if(number.length==3){
                    substract = Double.parseDouble(number[1]) - Double.parseDouble(number[2]);
                }
                input = substract+"";
            }
            catch(Exception e){

            }
        }
        String n[]=input.split("\\.");
        if(n.length>1) {
            if (n[1].equals("0")) {
                input = n[0];
            }
        }
        Screen.setText(input);
    }
}